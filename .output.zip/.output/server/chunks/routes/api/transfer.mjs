import { d as defineEventHandler } from '../../runtime.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';

const transfer = defineEventHandler((event) => {
  return {
    hello: "world"
  };
});

export { transfer as default };
//# sourceMappingURL=transfer.mjs.map
